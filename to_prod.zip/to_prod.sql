-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: omer
-- ------------------------------------------------------
-- Server version	5.7.17-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_team`
--

DROP TABLE IF EXISTS `base_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `english_team_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_number` int(11) DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `team_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_team`
--

LOCK TABLES `base_team` WRITE;
/*!40000 ALTER TABLE `base_team` DISABLE KEYS */;
INSERT INTO `base_team` VALUES (1,'Discovery Bay',15836,'Discovery Bay','United States','California','2017-03-29 18:35:46','2017-03-29 18:39:08','foreign_team'),(2,'EDUCATIONAL CENTER ISTOKI',40484,'Chelyabinsk','Russia','Chelyabinsk region','2017-03-29 18:35:46','2017-03-29 18:39:08','foreign_team'),(3,'Excelsior',35674,'Discovery Bay','USA','California','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(4,'Unnye Robinzony-4',31108,'Almaty','Kazakhstan','Auezov.','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(5,'Alash',40317,'Almaty','Kazakhstan','city','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(6,'Va-bank',40317,'Almaty','Kazakhstan','city','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(7,'La Grande Boissière (LGB)',44503,'Geneva','Switzerland','Geneva','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(8,'Lyceum 11 Chelyabinsk',43617,'Chelyabinsk','Russia','Chelyabinsk region','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(9,'NEW GENERATION',43518,'Smolensk','Russia','city','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(10,'Omer\'s Tail',42833,'Foune','Switzerland','Vaud','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(11,'Kremenkul Middle School',8,'countryside Kremenkul','Russia','Sosnovskiy municipal district','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(12,'Flash up',36107,'Санкт-Петербург','Россия','Северо-Запад','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(13,'FLASH',36107,'Санкт-Петербург','Россия','Северо-Запад','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(14,'School  #21',36270,'Miass','Russia','Chelybinsk, South Urals','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team'),(15,'The Three Mus-key-teers',42833,'Founex','Switzerland','Vaud','2017-03-29 18:35:47','2017-03-29 18:39:08','foreign_team');
/*!40000 ALTER TABLE `base_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coach`
--

DROP TABLE IF EXISTS `coach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dietary_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medical_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patronymic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t_shirt_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coach`
--

LOCK TABLES `coach` WRITE;
/*!40000 ALTER TABLE `coach` DISABLE KEYS */;
INSERT INTO `coach` VALUES (1,'dovemedia@aol.com',NULL,NULL,'1820 Anchorage Way, Discovery Bay, CA USA 94505','Dove','Amanda',NULL,'XL','1972-04-10','4G450487','2017-03-01','2022-03-01',NULL),(2,'dovemedia@aol.com',NULL,NULL,'550 Discovery Bay Blvd., Discovery Bay, CA 94505 USA','Capelli','Heather',NULL,'Adult Medium','1974-07-16','546110030','2016-07-17','2026-07-16',NULL),(3,'poko-next@yandex.ru',NULL,NULL,'Russia, Chelyabinsk, Naberezhnaya street, 3','Asatullina','Maria',NULL,'L','1977-08-05','7599187962','1999-12-08','2022-08-27',NULL),(4,'dovemedia@aol.com',NULL,NULL,'1820 Anchorage Way, Discovery Bay, CA USA 94505','Dove','Amanda',NULL,'XL','1972-04-10','4G450487','2017-03-01','2022-03-01',NULL),(5,'flyawaymom@hotmail.com',NULL,NULL,'351 Tulare Street, Brentwood, CA USA 94505','Austin','Lynn',NULL,'Medium','1963-12-04','447515772','2013-08-17','2018-08-18',NULL),(6,'belyayevakz1@mail.ru','no','no','Almaty, mkr.Aksay-2,h.1,apt.36','Kharitonova','Janneta',NULL,'M','2017-03-29','06684246','2017-03-29','2017-03-29',NULL),(7,'belyayevakz1@mail.ru','no','no','Almaty,mkr.Mamyr-3,H.32, apt.6','Shomanova','Nurbanu',NULL,'XL','1961-10-11','020503773','2008-01-25','2051-10-10',NULL),(8,'belyayevakz1@mail.ru','no','no','Djambyl.obl.Merken.r-n,s.Oytal,st.Michurina,H.75','Bondarenko','Vitaliy',NULL,'XL','1993-10-19','024357563','2009-12-02','2019-12-01',NULL),(9,'marcia.banks@ecolint.ch','none','Please note that I have two more boys to add as soon as I have their passport information.  Aggelos Kouris & Andrea D\'Ambrasio','Route de Presinge, 23    1241 Puplinge','Banks','Marcia',NULL,'Adult Small','1953-06-16','X4985535','2010-12-10','2020-12-09',NULL),(10,'poko-next@yandex.ru',NULL,NULL,'Russia, Chelyabinsk, Kirova street, 21','Knyazeva','Elena',NULL,'L','1973-10-02','7503003946','2002-11-29','2019-10-02',NULL),(11,'yliaav@mail.ru','no','no','Smolensk, Nakhimov\'s street, 33, 69','Averina','Julia',NULL,'XL','1979-03-28','6600 №103636','2000-11-27','2024-03-28',NULL),(12,'yliaav@mail.ru','no','no','Smolensk','Semenova','Nadezhda',NULL,'XL','1970-07-06','6604 №136043','2005-07-22','2035-07-06',NULL),(13,'slemoult@hotmail.com','None','Allergy animals, pollen','Chemin de la Petite Fontaine 3, 1270 Trelex, Switzerland','LeMoult','Michelle',NULL,'Adult Large','1972-08-06','469240541','2010-05-18','2020-05-17',NULL),(14,'Alekseevang51@mail.ru',NULL,NULL,'456501 village Kremenkul, Severnaya str. 10-1','Alekseeva','Nadezhda',NULL,'XXL','1951-06-01','7500 663633','2001-04-03','2030-06-01',NULL),(15,'tatiana7025@yandex.ru','-','-','195220 СПб, ул. Бутлерова д.14 кв.18','Смирнова','Татьяна',NULL,'L','1970-07-25','4015 № 324534','2015-09-18','2018-09-18',NULL),(16,'teu58@yandex.ru','-','-','г. Санкт-Петербург,пр-т Непокоренных,д.74,кв.400','Кривоченко','Анна',NULL,'m','2001-03-29','40 14 229429','2015-04-02','2018-04-02',NULL),(17,'teu58@yandex.ru','-','-','Санкт-Петербург, Пискаревский пр., 56-1-192','Титова','Елена',NULL,'m','1958-01-17','4003 825767','2003-04-24','2018-04-24',NULL),(18,'maximgunit@gmail.com','-','-','ул. Верности,48-59','Чевелий','Маким',NULL,'L','1995-07-27','40 15 309487','2015-08-15','2018-08-15',NULL),(19,'tpat@mail.ru',NULL,NULL,'Miass, Lihacheva st. , 26-32','Patrashkina','Tatiana',NULL,'L','1970-02-07','7 514 593 703','2015-02-25','2057-02-07',NULL),(20,'dianepwhitney@yahoo.com','None','None','Rue du Vieux-Pressoir 5, 1297 Founex, Switzerland','Whitney','Diane',NULL,'Adult Medium','1971-01-20','504173704','2013-01-31','2023-01-30',NULL);
/*!40000 ALTER TABLE `coach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coaches_teams`
--

DROP TABLE IF EXISTS `coaches_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coaches_teams` (
  `base_team_id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  PRIMARY KEY (`base_team_id`,`coach_id`),
  KEY `IDX_4209DD521D6A61CA` (`base_team_id`),
  KEY `IDX_4209DD523C105691` (`coach_id`),
  CONSTRAINT `FK_4209DD521D6A61CA` FOREIGN KEY (`base_team_id`) REFERENCES `base_team` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_4209DD523C105691` FOREIGN KEY (`coach_id`) REFERENCES `coach` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coaches_teams`
--

LOCK TABLES `coaches_teams` WRITE;
/*!40000 ALTER TABLE `coaches_teams` DISABLE KEYS */;
INSERT INTO `coaches_teams` VALUES (1,1),(1,2),(2,3),(3,4),(3,5),(4,6),(5,7),(6,8),(7,9),(8,10),(9,11),(9,12),(10,13),(11,14),(12,15),(12,16),(13,17),(13,18),(14,19),(15,20);
/*!40000 ALTER TABLE `coaches_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `director_user`
--

DROP TABLE IF EXISTS `director_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `director_user` (
  `id` int(11) NOT NULL,
  `gender` int(11) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `association` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dietary_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medical_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patronymic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t_shirt_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `native_first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `native_surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `native_patronymic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_85316757BF396750` FOREIGN KEY (`id`) REFERENCES `fos_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `director_user`
--

LOCK TABLES `director_user` WRITE;
/*!40000 ALTER TABLE `director_user` DISABLE KEYS */;
INSERT INTO `director_user` VALUES (34,1,'St-Petersburg, Nauki 55-10','+7-921-75-999-88','Russia, North-West Association','-','-','Skvortcova','Natalia',NULL,'M','1968-08-24','4005 695121','2017-03-09','2017-03-09','St-Petersburg',NULL,NULL,NULL),(35,1,'SPb,Lanskoe shosse, 69-86','+7-9213495311','Russia','-','-','Danilova','Liudmila',NULL,'xxl','1961-05-09','4005 859791','2019-02-27','2020-03-10','RF',NULL,NULL,NULL),(36,1,'Spb, Rustavely 37, 7','89215587792','Russia','-','-','Kitaeva','Aleksandra',NULL,'l','1987-04-09','4706  090953','2019-07-11','2019-11-28','RF',NULL,NULL,NULL),(37,1,'SPb, 3-ya Sovetskaya 4, 3','+7-911-264-3606','Russia','-','-','Shurstina','Olga',NULL,'l','1991-05-19','4011 344563','2019-07-23','2019-07-04','RF',NULL,NULL,NULL),(38,1,'SPb, Rustaveli, 37-21','+79052057820','Russia','-','-','Egorova','Irina',NULL,'XL','1965-10-03','40 10 115550','2010-10-10','2020-10-18','Saint Petersburg',NULL,NULL,NULL),(39,0,'SPb, Nauki, 55-10','+79214036456','Russia','-','-','Khudyakov','Igor',NULL,'XL','1967-01-03','40 11 396526','2012-01-17','2022-01-16','RF',NULL,NULL,NULL),(40,0,'Hermann-Elflein-Str. 18b, 14467 Potsdam, Germany','+491733674286','Germany','none','none','Hübner','Stefan',NULL,'M','1980-03-18','C3MXC341P','2016-02-23','2026-02-22','Germany',NULL,NULL,NULL),(41,0,'Friedrichsberger Str. 4','+491718391738','Germany',NULL,NULL,'List','Sebastian',NULL,'M','1989-08-11','C3J3F45FV','2016-08-22','2026-08-21','German',NULL,NULL,NULL),(42,1,'2329 11th St N, Apt. 303, Arlington, VA, USA, 22201','+19196024869','USA','None','None','Cordes','Jaime',NULL,'M','1989-06-14','459846635','2009-08-28','2019-08-27','USA',NULL,NULL,NULL),(43,0,'187-L-A, Model Town, Sonipat','9896812950','INDIA',NULL,NULL,'Sachdeva','Prabhat',NULL,'XXXL','1974-11-11','J6718682','2011-05-03','2021-05-02','INDIAN',NULL,NULL,NULL),(44,1,'007/Block 1, Kirti Appts. Mayur Vihar Extension, New Delhi','9899111714','INDIA',NULL,NULL,'Phull','Madhu',NULL,'XXXL','1946-09-15','Z3540633','2016-03-29','2026-03-28','INDIAN',NULL,NULL,NULL),(46,0,'test','test','test',NULL,NULL,'test','test',NULL,'test','2017-03-22','test','2017-03-22','2017-03-22','test',NULL,NULL,NULL),(47,0,'Pappelweg 1, 14624 Seeburg','+49 17634450561','Germany','non','non','Dr. Melzer','Reinhard (Max)',NULL,'XXL','1955-12-14','C3YLFFJYK','2011-02-22','2021-02-21','D-14624',NULL,NULL,NULL),(48,0,'ul. Herkulesa 30, 80-299 Gdansk, Poland','+48695216350','Poland',NULL,NULL,'Czerwonka','Jan',NULL,'XL','1993-01-02','ED2391781','2012-02-13','2022-02-13','Polish',NULL,NULL,NULL),(49,1,'Minsk, st.Kazimirovskaya 33-175','+375291223138','Belarus',NULL,NULL,'Bardziyan','Maryna',NULL,'M','1996-08-12','MP3036522','2012-03-07','2021-08-12','Belarus','Марина','Бардиян','Андреевна'),(50,1,'Minsk, Parnikovaya 3/3, 96','+37529 369 38 56','Belarus','-','-','Vecher','Polina',NULL,'s','1996-02-08','MP3080942','2012-05-04','2021-02-08','Minsk','Полина','Вечер','Анатольевна'),(51,0,'Teplichnaya St. 28-1, Minsk, Belarus 220114','+375447526612','Belarus','Vegetarians',NULL,'Buloichyk','Darya',NULL,'S','1995-07-16','MP3948542','2017-03-01','2027-03-01','Republic of Belarus','Дарья','Булойчик','Николаевна'),(52,1,'Calea Vitan 199, bl. 52, sc. 1, ap. 4, et. 2, sector 3, Bucharest','+40747153333','Romania',NULL,NULL,'Ciurea','Cristina',NULL,'L','1996-12-27','051727487','2013-02-06','2018-02-06','romanian',NULL,NULL,NULL),(53,NULL,NULL,NULL,NULL,NULL,NULL,'super_admin','super_admin','super_admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `director_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foreign_team`
--

DROP TABLE IF EXISTS `foreign_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `foreign_team` (
  `id` int(11) NOT NULL,
  `school` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `problem` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `division` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_currency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_77727AFFBF396750` FOREIGN KEY (`id`) REFERENCES `base_team` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foreign_team`
--

LOCK TABLES `foreign_team` WRITE;
/*!40000 ALTER TABLE `foreign_team` DISABLE KEYS */;
INSERT INTO `foreign_team` VALUES (1,'Discovery Bay Elementary','1820 Anchorage Way','2 Odd-a-bot','II','Same coach and one same team member as Excelsior 35674','3'),(2,'EDUCATIONAL CENTER ISTOKI','Klary Cetkin str. 13 Chelyabinsk, 454080','5','3','Teams \"Lyceum 11 Chelyabinsk\" and \"EDUCATIONAL CENTER ISTOKI\" have the same coaches: Maria Asatullina and Elena Knyazeva. We need to live in ONE place, because it\'s very difficult to get in touch when our teams live in different places.','1'),(3,'Excelsior Middle School','1820 Anchorage Way','#2 Odd-a-bot','II','Same coach and one same member as Discovery Bay member #15836','3'),(4,'Gymnasium 132','mkr. Aksay-2','Pr.5','I div.','no','2'),(5,'Lyceum Arystan','Beskaynar, st.Djambyla,67','5','3',NULL,NULL),(6,'Lyceum Arystan','Beskaynar,st.Jambula,67','3','3',NULL,NULL),(7,'International School of Geneva','Route de Chêne, 62','#  3 It\'s Time Omer','One','none','0'),(8,'Lyceum 11','6 Timiryazeva str. Chelyabinsk, 454000','3','2','1)Teams \"Lyceum 11 Chelyabinsk\" and \"EDUCATIONAL CENTER ISTOKI\" have the same coaches: Maria Asatullina and Elena Knyazeva. We need to live in THE SAME place, because it\'s very difficult to get in touch when our teams live in different places. \n2) Elena K','1'),(9,'33','Smolensk, Kirova str., 22A','3','2','no','1'),(10,'International School of Geneva La Chat','2, Chemin de la Ferme, 1297 Founex, Switzerland','Problem 3','II','None','2'),(11,'Kremenkul Middle School','456501 Lenina str. 17, Kremenkul, Chelyabinsk region','Problem №4 Ready, Set, Balsa, Build!','3',NULL,'1'),(12,'#156','Меншиковский пр, 15-3','2','2','-',NULL),(13,'#156','Меншиковский пр, 15-3','3','2','-',NULL),(14,'School  #21','456300, Miass, Lihacheva st., 33A','II','III',NULL,'1'),(15,'International School of Geneva La Chat','2, Chemin de la Ferme','Problem 5','II','None','2');
/*!40000 ALTER TABLE `foreign_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fos_user`
--

DROP TABLE IF EXISTS `fos_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fos_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `user_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_957A6479C05FB297` (`confirmation_token`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fos_user`
--

LOCK TABLES `fos_user` WRITE;
/*!40000 ALTER TABLE `fos_user` DISABLE KEYS */;
INSERT INTO `fos_user` VALUES (34,'skvonata@mail.ru','skvonata@mail.ru','skvonata@mail.ru','skvonata@mail.ru',1,NULL,'$2y$13$vQe0ui3ce6KSY2DBEnj3vePuAbF/mqxsz1B2YcbCson9tn2sYbpqO',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(35,'lyu-dan@yandex.ru','lyu-dan@yandex.ru','lyu-dan@yandex.ru','lyu-dan@yandex.ru',1,NULL,'$2y$13$/uKJb1PBgLTTGM/gKAh9ze/j1oHn1iX0Q7i3eNHAlWO.NJ.CG80TG',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(36,'aleksandra-kitaeva@mail.ru','aleksandra-kitaeva@mail.ru','aleksandra-kitaeva@mail.ru','aleksandra-kitaeva@mail.ru',1,NULL,'$2y$13$GwO2zt3auFZL.IalEkA/yewbUMAZCpDZP3sZhfevr/XLaW4Z5t8Y6',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(37,'Pernataya12@mail.ru','pernataya12@mail.ru','Pernataya12@mail.ru','pernataya12@mail.ru',1,NULL,'$2y$13$3dgqfra69Zno5KAtrF.SlOiP7ZlGvPWaTvBNO2ud/AWWzfgpwCNhG',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(38,'iraegor@yandex.ru','iraegor@yandex.ru','iraegor@yandex.ru','iraegor@yandex.ru',1,NULL,'$2y$13$vI1M8qwlQ7H1E1SrrC/iaeHQcL/UzDaUj.kW7.XLlfV5bMQ0a1Z4C',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(39,'igorkhud67@mail.ru','igorkhud67@mail.ru','igorkhud67@mail.ru','igorkhud67@mail.ru',1,NULL,'$2y$13$e67MMWIH8WqS/tic9l9NieIuqWSS8a0ndMxqoyg/1au3VUzIpkBSK',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(40,'stefan@odysseyofthemind.de','stefan@odysseyofthemind.de','stefan@odysseyofthemind.de','stefan@odysseyofthemind.de',1,NULL,'$2y$13$copn5ZOmTZ8N8xj5YVsKjebsZgnJYs6pz2U1q0xptWCzJll7WSK4S',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(41,'basti@mlist-online.de','basti@mlist-online.de','basti@mlist-online.de','basti@mlist-online.de',1,NULL,'$2y$13$ZjFVyFYegQFnEbEI.krMtukAhJsDCSNoiAF19N.5Oo/BILO.p8N6G',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(42,'jaime.cordes@gmail.com','jaime.cordes@gmail.com','jaime.cordes@gmail.com','jaime.cordes@gmail.com',1,NULL,'$2y$13$NIaIFG1IUFPblJiJAhuyNulsPB/O3WAO6.PpmvBjYnkHZeDt9uRoi',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(43,'suprabhat.ens@gmail.com','suprabhat.ens@gmail.com','suprabhat.ens@gmail.com','suprabhat.ens@gmail.com',1,NULL,'$2y$13$dKQb356D3reR2DaXfOaF9u9KYoXjcXK3C4puk566/lxaUdhuMqFmm',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(44,'madhu46@gmail.com','madhu46@gmail.com','madhu46@gmail.com','madhu46@gmail.com',1,NULL,'$2y$13$H.ySxSIU7v1yoyTffWl6/uSjSvEV5zfyQ6spJkEzWpdkSft2uDhpu',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(46,'marina_bard@tut.by','marina_bard@tut.by','marina_bard@tut.by','marina_bard@tut.by',1,NULL,'$2y$13$jm0CY48rC4ux5yV6MLv3tOyw9Z/lI.AeMqzInmFqhyCUkBHEEWEv.',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(47,'office@odysseyofthemind.de','office@odysseyofthemind.de','office@odysseyofthemind.de','office@odysseyofthemind.de',1,NULL,'$2y$13$Kv4HnwgP9H/2Fq/Q2rM1FOEsTDlslJqou/75KvfppaZdYNb9q11va',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(48,'czerwonka.j@gmail.com','czerwonka.j@gmail.com','czerwonka.j@gmail.com','czerwonka.j@gmail.com',1,NULL,'$2y$13$Sd6oG9x83UT5Ptrgi08VDO.6arAseU8ZC2njUcAirSTEcT58pYj8a',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(49,'marina.bard.96@gmail.com','marina.bard.96@gmail.com','marina.bard.96@gmail.com','marina.bard.96@gmail.com',1,NULL,'$2y$13$peqkPXrqMDq3pM.HoMc8h.JZGMLvd2.C79rk0xAYxV0URBfqxSZkW',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(50,'kennyneverdai@mail.ru','kennyneverdai@mail.ru','kennyneverdai@mail.ru','kennyneverdai@mail.ru',1,NULL,'$2y$13$Aq8OFjfa.EGFxSiB3xYcn.rs8xAl7HUSt69qMOMI6VStl4ewzZOku',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(51,'kuzhaldaria@gmail.com','kuzhaldaria@gmail.com','kuzhaldaria@gmail.com','kuzhaldaria@gmail.com',1,NULL,'$2y$13$6JxetUENe28nmvEsQXJygu/8/E/3A1ft7KWJzd45UYhc0WRh1ISRe',NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_JUDGE\";}','official_user'),(52,'ciurea.cristina27@gmail.com','ciurea.cristina27@gmail.com','ciurea.cristina27@gmail.com','ciurea.cristina27@gmail.com',1,NULL,'$2y$13$PpKjsx.Kbp2gLpT7KaSQl.xJWFafYe.n.0yhf6mzovAzo8Kg5GIgi',NULL,NULL,NULL,'a:1:{i:0;s:13:\"ROLE_DIRECTOR\";}','official_user'),(53,'super_admin','super_admin','super_admin','super_admin',1,NULL,'$2y$13$SrjGnD/7m4mqfdLXBbjB3ul/ddAJI.MVe/cpqsEH9Yzi2bIbaAGnq','2017-03-29 18:56:43',NULL,NULL,'a:1:{i:0;s:16:\"ROLE_SUPER_ADMIN\";}','official_user'),(54,'admin','admin','admin','admin',1,NULL,'$2y$13$x3GB6gX1gyvQh1tX6vWrUu7Fbg/wPOpAXpCxF13YfjxKFebYjBGlm','2017-03-29 18:42:45',NULL,NULL,'a:1:{i:0;s:15:\"ROLE_MAIN_ADMIN\";}','official_user');
/*!40000 ALTER TABLE `fos_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_people`
--

DROP TABLE IF EXISTS `other_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `other_people` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `team_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dietary_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medical_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patronymic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t_shirt_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1910503E296CD8AE` (`team_id`),
  CONSTRAINT `FK_1910503E296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `base_team` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_people`
--

LOCK TABLES `other_people` WRITE;
/*!40000 ALTER TABLE `other_people` DISABLE KEYS */;
INSERT INTO `other_people` VALUES (1,1,'chaperone','dovemedia@aol.com',NULL,NULL,'2254 Prestwick Drive, Discovery Bay, CA 94505 USA','Healy','Janine',NULL,'Adult small','1975-10-11','482657054','2011-04-14','2021-04-13',NULL),(2,1,'chaperone','dovemedia@aol.com',NULL,NULL,'2254 Prestwick Drive, Discovery Bay, CA 94505 USA','Healy','Timothy',NULL,'Adult XL','1975-10-13','459719051','2010-03-29','2020-03-28',NULL),(3,1,'sibling','dovemedia@aol.com',NULL,NULL,'2254 Prestwick Drive, Discovery Bay, CA 94505 USA','Healy','Kendall',NULL,'Child Large','2008-02-20','560948793','2017-01-03','2022-01-02',NULL),(4,1,'chaperone','dovemedia@aol.com',NULL,NULL,'1440 Shell Ct., Discovery Bay, CA 94505 USA','Moseley','Katy',NULL,'Adult Medium','1970-05-18','546228111','2016-10-19','2026-10-18',NULL),(5,1,'Chaperone','dovemedia@aol.com',NULL,NULL,'Edgeview Drive, Discovery Bay, CA 94505 USA','Taylor','Rod',NULL,'Adult XL','1962-02-13','pending','2017-03-02','2022-02-02',NULL),(6,1,'sibling','dovemedia@aol.com',NULL,NULL,'1301 St. Andrews Dr, Discovery Bay, CA 94505','Eaton','Evan',NULL,'Child Medium','2008-03-21','pending','2017-03-02','2022-03-01',NULL),(7,1,'chaperone','dovemedia@aol.com',NULL,NULL,'Riverlake Road, Discovery Bay, CA 94505 USA','Enos','Kathy',NULL,'Adult Medium','1981-03-30','558418466','2016-12-21','2021-12-20',NULL),(8,1,'chaperone','dovemedia@aol.com',NULL,NULL,'905 Discovery Bay Blvd., Discovery Bay, CA 94505 USA','Duckworth-Iljas','Juile',NULL,'Adult Large','1967-06-22','440037107','2008-05-07','2018-05-06',NULL),(9,1,'chaperone','dovemedia@aol.com',NULL,NULL,'905 Discovery Bay Blvd., Discovery Bay, CA 94505 USA','Iljas','David',NULL,'Adult XXL','1968-10-08','480674609','2011-06-08','2021-06-07',NULL),(10,1,'sibling','dovemedia@aol.com',NULL,NULL,'905 Discovery Bay Blvd., Discovery Bay, CA 94505 USA','Duckworth','Andrew',NULL,'Adult Small','2005-06-07','550451057','2016-10-19','2021-10-18',NULL),(11,3,'Chaperone','dovemedia@aol.com',NULL,NULL,'1820 Anchorage Way, discovery Bay, CA USA 94505','Dove','Bryan',NULL,'XXL','1970-03-02','542614208','2016-03-24','2026-03-23',NULL),(12,3,'Chaperone','dovemedia@aol.com',NULL,NULL,'Edgeview Drive, Discovery Bay, CA 94505 USA','Taylor','Rod',NULL,'Adult XL','1962-02-13','pending','2017-03-02','2022-02-02',NULL),(13,5,'AD','belyayevakz1@mail.ru','no','no','Almaty, mkr. Orbita-4,H.8, apt.77','Belyayeva','Lyubov',NULL,'XL','1952-12-17','032573987','2012-01-04','2022-01-03',NULL),(14,9,'pаrent','yliaav@mail.ru','no','no','smolensk','Nosikov','Dmitry',NULL,'XL','1972-07-31','6602 №551824','2002-06-17','2017-07-31',NULL),(15,13,'помощник тренера','teu58@yandex.ru','-','-','Санкт-Петербург, Меншиковский пр., 15-1-77','Щербина','Марианна',NULL,'m','2000-02-09','4013957313','2014-02-24','2018-02-24',NULL);
/*!40000 ALTER TABLE `other_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem`
--

DROP TABLE IF EXISTS `problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem`
--

LOCK TABLES `problem` WRITE;
/*!40000 ALTER TABLE `problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_member`
--

DROP TABLE IF EXISTS `team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `dietary_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `medical_concerns` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patronymic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t_shirt_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6FFBDA1296CD8AE` (`team_id`),
  CONSTRAINT `FK_6FFBDA1296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `base_team` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_member`
--

LOCK TABLES `team_member` WRITE;
/*!40000 ALTER TABLE `team_member` DISABLE KEYS */;
INSERT INTO `team_member` VALUES (1,1,NULL,NULL,'1820 Anchorage Way, Discovery Bay, CA 94505 USA','Dove','Daniel',NULL,'Adult Small','2006-05-24','555959117',NULL,'2022-01-10',NULL),(2,1,NULL,NULL,'550 Discovery Bay Blvd, Discovery Bay, CA 94505 USA','Capelli','Gavin',NULL,'Adult Small','2006-06-27','548357775',NULL,'2021-08-16',NULL),(3,1,NULL,NULL,'Edgeview Drive, Discovery Bay, CA 94505 USA','Taylor','Wyatt',NULL,'Adult medium','2003-04-08','pending',NULL,'2017-03-02',NULL),(4,1,NULL,NULL,'2254 Prestwick Drive, Discovery Bay, CA USA 94505','Healy','Caden',NULL,'Adult small','2005-12-15','560948792',NULL,'2022-01-02',NULL),(5,1,NULL,NULL,'1440 Shell Ct., Discovery Bay, CA 94505 USA','Moseley','Tory',NULL,'Adult Small','2006-08-10','558334700',NULL,'2021-11-22',NULL),(6,1,NULL,NULL,'Riverlake Raod, Discovery Bay, CA 94505 USA','Enos','Tyler',NULL,'Adult small','2006-01-12','558418467',NULL,'2021-12-20',NULL),(7,1,NULL,NULL,'905 Discovery Bay Blvd, Discovery Bay, CA 94505 USA','Duckworth','Abbygail',NULL,'Adult Small','2006-08-19','550451064',NULL,'2021-10-18',NULL),(8,2,NULL,NULL,'Russia, Chelyabinsk, Kirova street, 21','Knyazeva','Alexandra',NULL,'M','1999-03-17','7512257284',NULL,'2019-04-19',NULL),(9,2,NULL,NULL,'Russia, Chelyabinsk, Naberezhnaya street, 3','Asatullina','Diana',NULL,'M','2000-11-01','7514558194',NULL,'2020-11-24',NULL),(10,2,NULL,NULL,'Russia, Chelyabinsk, Sverdlovsky street','Narskaya','Alexandra',NULL,'M','2000-02-25','7513425342',NULL,'2020-03-19',NULL),(11,2,NULL,NULL,'Russia, Chelyabinsk, Severo-Krimskaya street','Smagina','Maria',NULL,'L','1999-06-17','7513306948',NULL,'2019-08-07',NULL),(12,2,NULL,NULL,'Russia, Chelyabinsk, Larzo','Naumenko','Vasilina',NULL,'M','2001-10-06','7515701801',NULL,'2021-10-20',NULL),(13,2,NULL,NULL,'Russia, Chelyabinsk, Victory street','Vigerich','Ekaterina',NULL,'S','1999-03-06','7512257120',NULL,'2019-04-15',NULL),(14,3,NULL,NULL,'1820 Anchorage Way, Discovery Bay, CA 94505 USA','Dove','David',NULL,'Adult Large','2003-03-30','555959118',NULL,'2022-01-10',NULL),(15,3,NULL,NULL,'351 Tulare St, Brentwood, CA USA 94505','Austin','Trevor',NULL,'Adult Large','2002-11-22','539568336',NULL,'2021-02-21',NULL),(16,3,NULL,NULL,'Edgeview Drive, Discovery Bay, CA 94505 USA','Taylor','Wyatt',NULL,'Adult medium','2003-04-08','pending',NULL,'2017-03-02',NULL),(17,3,NULL,NULL,'6478 Green Castle Circle, Discovery Bay, CA USA 94505','Martinez','Tyler',NULL,'Adult Medium','2003-02-21','564908539',NULL,'2022-01-18',NULL),(18,4,NULL,'no','Almaty,mkr.Jetysu-2,h.27,apt.6','Jomaptkanova','Aijan',NULL,'S','2017-03-29','0554378',NULL,'2017-03-29',NULL),(19,4,NULL,'no','Almaty< mkr. Mamyr-1, h.29/8, apt.13','Begaydarova','Dayana',NULL,'S','2009-05-07','0790324',NULL,'2017-03-29',NULL),(20,4,NULL,'no','Almaty,mkr. Jetysu-2, h.2,apt.13','Paltahunova','Arzu',NULL,'S','2017-03-29','0810791',NULL,'2017-03-29',NULL),(21,4,NULL,'no','Almaty,mkr.Aksay-2,h.15,apt.6','Buyanov','Igor',NULL,'S','2009-01-25','0847233',NULL,'2017-03-29',NULL),(22,4,NULL,'no','Almaty,mkr.Aksay-2,h.18,apt.34','Anuarbekov','Amir',NULL,'S','2009-03-26','0789785',NULL,'2017-03-29',NULL),(23,4,NULL,'no','Almaty, mkr.Kalkaman-,ul.Smaylova,h.175','Mamutov','Mansur',NULL,'M','2017-03-29','0033802',NULL,'2017-03-29',NULL),(24,5,NULL,'no','Astana, st.Yakushkeevicha,H.8/2,apt.410','Akimjanov','Eldar',NULL,'L','2001-07-21','1903 N 0057218',NULL,'2017-07-21',NULL),(25,5,NULL,'no','Almaty,st.Karasay batyra,H 68,apt.5','Ashigaliyev','Amir',NULL,'XL','2000-08-04','040513545',NULL,'2026-08-10',NULL),(26,5,NULL,'no','Almaty,st.Shagabutdinova, H.125A, apt.5','Sultanuly','Kamal',NULL,'L','2000-09-03','040617985',NULL,'2026-09-05',NULL),(27,5,NULL,'no','Almaty, st.Djumaliyeva,H.150,apt.20','Luchenkov','Marsel',NULL,'L','2000-05-17','040654451',NULL,'2026-09-14',NULL),(28,5,NULL,'no','Zapadno-Kaz.obl.Uralsk,st.Djangir-khan, H.57','Djanabay','Temirlan',NULL,'L','2000-06-05','041314002',NULL,'2026-06-14',NULL),(29,5,NULL,'no','Almat.obl. Chilik, H.20','Kanatbek','Nurjan',NULL,'L','2000-11-16','040901579',NULL,'2026-11-20',NULL),(30,5,NULL,'no','Almaty,Kamenka,st.Kushelekova.H24','Muhamedjan','Nartbek',NULL,'L','2000-03-11','040161323',NULL,'2026-05-26',NULL),(31,6,NULL,'no','Almaty,mkr.Aksay -3B,H.334,apt.18','Abdilmajin','Abylaykhan',NULL,'L','2000-11-01','040900417',NULL,'2026-11-20',NULL),(32,6,NULL,'no','Astana,st.Turan,H.72,apt.76','Nugmanov','Anuar',NULL,'L','2000-10-11','040900669',NULL,'2026-11-20',NULL),(33,6,NULL,'no','Almat.obl., s.Pokrovka,st.Komsomolskay','Rayimbekov','Aldiyar',NULL,'L','2001-07-12','1907 N 000000637',NULL,'2017-07-12',NULL),(34,6,NULL,'no','Vostochno-Kaz.obl.Semey,st.Chaydjunusova,H.160,apt.1','Uskenbayeyv','Ramazan',NULL,'M','2000-12-26','042132226',NULL,'2026-12-26',NULL),(35,6,NULL,'no','Almaty, st.Nauryzbay batyr,H.70,apt.21','Bolatuly','Adil',NULL,'L','2000-10-23','040860257',NULL,'2026-11-08',NULL),(36,6,NULL,'no','Almat.obl, Kaskelen,st. Rayimbeka,H.60A,apt.16','Shashubay','Gasyr-Galam',NULL,'L','2000-12-08','041011501',NULL,'2026-12-22',NULL),(37,6,NULL,'no','Kapchagay,mkr.4,H.41,APT 21','Baratov','Rishat',NULL,'L','2000-10-31','040849177',NULL,'2026-11-06',NULL),(38,7,NULL,'none','9, Rue Emile Yung, 1205 Geneva, Switzerland','Kottler','Zoe',NULL,'Youth medium','2009-04-21','PAB871837',NULL,'2020-12-28',NULL),(39,7,NULL,'none','17,Avenue Pictet-de-Rochemont · 1207 Genève · Switzerland','Menagarishvili','Luca Anthony (boy)',NULL,'Youth Large','2009-04-12','NM94K9J80',NULL,'2020-07-10',NULL),(40,7,NULL,'none','6 chemin de la Bise, 1222 Vésenaz, Switzerland','Monnickendam','Elie (boy)',NULL,'Adult Small','2008-02-09','X0207502',NULL,'2017-09-27',NULL),(41,7,NULL,'none','16, chemin de la Butte · 1228 Plan-les-Ouates · Switzerland','Orfanos','Georgios (boy)',NULL,'Youth medium','2009-05-04','AN7016939',NULL,'2019-08-04',NULL),(42,7,NULL,'none','Chemin Edouard Tavan 8C, 1206 Geneva','Thomas','Anne-Bennett (girl)',NULL,'Youth Large','2007-11-30','498337785',NULL,'2018-01-13',NULL),(43,8,NULL,NULL,'Russia, Chelyabinsk, Kalinina street','Mu','Rui',NULL,'M','2005-01-15','G51433679',NULL,'2019-03-31',NULL),(44,8,NULL,NULL,'Russia, Chelyabinsk, Naberezhnaya street, 3','Asatullina','Andge',NULL,'S','2004-10-23','Birth certificate: I-ИВ №584123',NULL,'2018-11-01',NULL),(45,8,NULL,NULL,'Russia, Chelyabinsk, Victory street','Rogacheva','Anna',NULL,'S','2003-12-22','Birth certificate: I-ИВ № 766534',NULL,'2018-01-15',NULL),(46,8,NULL,NULL,'Russia, Forest-park street','Potlov','Dmitry',NULL,'M','2003-09-08','Birth certificate: I-ИВ № 787518',NULL,'2018-01-16',NULL),(47,8,NULL,NULL,'Russia, Chelyabinsk, AMZ','Smirnov','Danil',NULL,'M','2004-01-22','Birth certificate: II-ИВ № 781844',NULL,'2018-02-22',NULL),(48,8,NULL,NULL,'Russia, Chelyabinsk, Kirova street','Sevruk','Artyom',NULL,'M','2003-05-07','Birth certificate: I-ИВ № 704278',NULL,'2018-01-25',NULL),(49,8,NULL,NULL,'Russia, Chelyabinsk, Kalinina street','Germes','Mihail',NULL,'M','2002-10-29','7516866778',NULL,'2022-11-29',NULL),(50,9,NULL,'no','Smolensk','Averina','Maya',NULL,'S','2005-08-16','I-МП №592670',NULL,'2019-08-16',NULL),(51,9,NULL,'no','Smolensk','Andreenkova','Elizabeth',NULL,'S','2005-04-21','I-МП №585423',NULL,'2017-05-03',NULL),(52,9,NULL,'no','Smolensk','Nosikov','Michael',NULL,'S','2005-09-19','I-МП №594411',NULL,'2017-09-22',NULL),(53,9,NULL,'no','Smolensk','Starovoytov','Starovoytov Alexey',NULL,'S','2005-12-26','I-МП №596325',NULL,'2017-12-27',NULL),(54,9,NULL,'no','Smolensk','Tararina','Elizabeth',NULL,'S','2005-07-28','I-МП №585771',NULL,'2017-07-28',NULL),(55,9,NULL,'no','Smolensk','Schegolev','Alexander',NULL,'S','2005-06-24','I-МП №585653',NULL,'2017-06-29',NULL),(56,9,NULL,'no','Smolensk','Borisov','Kirill',NULL,'S','2005-09-16','I-МП №756464',NULL,'2017-04-28',NULL),(57,10,NULL,'None','Route des Fayards 255, 1290 Versoix, Switzerland','Capobianco','Alice',NULL,'Child Medium','2006-06-14','YA8539655',NULL,'2021-01-14',NULL),(58,10,NULL,'Allergy: cats, dogs, hay, pollen. Takes antihistamine daily and inhaler as needed','552 Rue du Pre de l\'Etang, 01170 Gex, France','Gill','Kayleigh',NULL,'Child Large','2005-03-01','PV4701743',NULL,'2018-10-02',NULL),(59,10,NULL,'None','321 Avenue des Alpes, 01220 Divonne-les-Bains, France','Upson Sandlund','Freja',NULL,'Child Large','2004-09-16','PJ7974007',NULL,'2019-06-30',NULL),(60,10,NULL,'None','Route de Marnex 5, 1291 Commugny, Switzerland','Feldbaum','Maddox',NULL,'Adult Small','2005-05-17','506083758',NULL,'2019-06-10',NULL),(61,10,NULL,'None','Chemin du Molard 9, 1297 Founex, Switzerland','Hess','Benjamin',NULL,'Child Large','2006-05-10','537546391',NULL,'2021-07-20',NULL),(62,11,NULL,NULL,'456501 village Kremenkul, Novosovhoznaya str. 24-1','Ponomareva','Yulia',NULL,'M','2001-03-13','7515 712650',NULL,'2021-03-13',NULL),(63,11,NULL,NULL,'456501 village Kremenkul, Salyutnaya str. 1-2','Biktimirova','Svetlana',NULL,'M','2001-11-28','7515 712563',NULL,'2021-11-28',NULL),(64,11,NULL,NULL,'456501 village Kremenkul, Gagarina str. 35-2','Hudyakova','Ekaterina',NULL,'M','2001-04-15','7515 637140',NULL,'2021-04-15',NULL),(65,11,NULL,NULL,'456501 village Sadoviy, Pervomayskaya str. 34-7','Vlasov','Evgeniy',NULL,'L','2001-02-19','7514 538160',NULL,'2021-02-19',NULL),(66,11,NULL,NULL,'456504 village Severniy, Lesnaya str. 2-2','Kozhevnikov','Danil',NULL,'L','2001-10-24','7515 711883',NULL,'2021-10-24',NULL),(67,11,NULL,NULL,'456502 village Mamaeva, Molodezhnaya str. 3','Ponomarev','Maksim',NULL,'L','2001-08-09','7515 637606',NULL,'2021-08-09',NULL),(68,11,NULL,NULL,'456502 vilage Almeeva, 1 Maya str. 19-A','Ishkinin','Ruslan',NULL,'L','2002-06-03','7516 790131',NULL,'2022-06-03',NULL),(69,12,NULL,'-','Санкт-Петербург, Пискаревский пр.,46-2-21','Безверхов','Даниил',NULL,'m','2004-01-28','I-AK 760160',NULL,'2018-03-16',NULL),(70,12,NULL,'-','Санкт-Петербург, Пискаревский пр., 159-8-133','Денисов','Виталий',NULL,'M','2004-12-14','I-CU 726199',NULL,'2018-04-19',NULL),(71,12,NULL,'-','Санкт-Петербург, пр. Непокоренных, 74-163','Иванова','Алина',NULL,'m','2004-05-06','I-AK 785400',NULL,'2018-05-28',NULL),(72,12,NULL,'-','Санкт-Петербург, ул. Верности 50-29','Кашапова','Анна',NULL,'m','2004-11-23','I-AK 821066',NULL,'2018-12-19',NULL),(73,12,NULL,'-','Санкт-Петербург, Пискаревский пр., 151-17','Липова','Юлия',NULL,'m','2004-09-05','I-AK 806306',NULL,'2018-10-06',NULL),(74,12,NULL,'-','Санкт-Петербург, Меншиковский пр., 15-2-85','Муравьев','Евгений',NULL,'m','2005-01-21','I-AK 833634',NULL,'2017-03-01',NULL),(75,12,NULL,'-','Санкт-Петербург, Пискаревский пр., 56-3-57','Петров','Тимофей',NULL,'m','2004-01-02','I-AK 768371',NULL,'2018-02-07',NULL),(76,13,NULL,'-','Санкт-Петербург, Пискаревский пр., 155-2-73','Бондаренко','Дарья',NULL,'m','2004-08-12','I-AK 780536',NULL,'2018-09-02',NULL),(77,13,NULL,'-','Санкт-Петербург, ул. Руставели, 2-11','Винокуров','Александр',NULL,'L','2004-03-16','I-AK 775124',NULL,'2018-04-17',NULL),(78,13,NULL,'-','Санкт-Петербург, Руставели 6-16','Давыдов','Роман',NULL,'m','2004-05-10','I-AK 785465',NULL,'2018-06-08',NULL),(79,13,NULL,'-','Санкт-Петербург, Непокоренных 74-381','Демиденко','Екатерина',NULL,'m','2004-02-24','III-ИВ 683005',NULL,'2018-05-08',NULL),(80,13,NULL,'-','Санкт-Петербург,Меншиковский пр., 13-1-101','Литвинюк','Виктория',NULL,'L','2004-07-20','I-AK 794476',NULL,'2018-08-12',NULL),(81,13,NULL,'-','Санкт-Петербург, Меншиковский пр., 5-2-2','Цыкунов','Александр',NULL,'L','2004-04-23','I-AK 760399',NULL,'2018-05-18',NULL),(82,14,NULL,NULL,'Miass, Lihacheva st. , 51-21','Dorofeev','Aleksey',NULL,'XL','2002-02-14','7 516 793 959',NULL,'2022-02-14',NULL),(83,14,NULL,NULL,'Miass, Naberezhnaya st., 37-60','Burlyakova','Anna',NULL,'L','2002-08-19','7 516 861 385',NULL,'2022-08-19',NULL),(84,14,NULL,NULL,'Miass, Vatutina,97','Patrashkina','Polina',NULL,'M','2005-08-23','I-ИВ # 896938',NULL,'2019-08-23',NULL),(85,14,NULL,NULL,'Miass, Lihacheva, 26 -88','Shiryaeva','Arina',NULL,'M','2005-08-02','I-ИВ # 896732',NULL,'2019-08-02',NULL),(86,14,NULL,NULL,'Miass, Lihacheva, 43-57','Kazymova','Svetlana',NULL,'M','2004-06-20','I-ИВ #821651',NULL,'2018-06-20',NULL),(87,15,NULL,'None','Rue du Vieux-Pressoir 5, 1297 Founex, Switzerland','Auton','Edwin',NULL,'Adult Small','2004-10-31','528654128',NULL,'2020-01-09',NULL),(88,15,NULL,'None','Chemin du Molard 9, 1297 Founex, Switzerland','Hess','Joshua',NULL,'Child Large','2004-10-13','537543241',NULL,'2022-04-20',NULL),(89,15,NULL,'None','76 Chemin de la Baronne, Divonne-les-Bains 01220, France','Churchill','William',NULL,'Child Large','2004-11-13','16AV05252',NULL,'2021-04-19',NULL),(90,15,NULL,'None','Rue des Fontaines 12, Signy 1274, Switzerland','Jamal','Neha',NULL,'Child Large','2005-05-03','530608677',NULL,'2020-07-08',NULL),(91,15,NULL,'None','10A Chemin le Grenier, Commugny 1291, Switzerland','Dorey','Declan',NULL,'Adult Small','2004-04-30','525730498',NULL,'2020-02-09',NULL);
/*!40000 ALTER TABLE `team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_info`
--

DROP TABLE IF EXISTS `travel_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `go_by` int(11) DEFAULT NULL,
  `transport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `station_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `station_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D1D2FA296CD8AE` (`team_id`),
  KEY `IDX_D1D2FAA76ED395` (`user_id`),
  CONSTRAINT `FK_D1D2FA296CD8AE` FOREIGN KEY (`team_id`) REFERENCES `foreign_team` (`id`),
  CONSTRAINT `FK_D1D2FAA76ED395` FOREIGN KEY (`user_id`) REFERENCES `fos_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_info`
--

LOCK TABLES `travel_info` WRITE;
/*!40000 ALTER TABLE `travel_info` DISABLE KEYS */;
INSERT INTO `travel_info` VALUES (21,NULL,'2017-04-23',2,'-','Zubrionok','St-Petersburg','19:00','0',34),(22,NULL,'2017-04-28',2,'-','Zubrionok','ST-Petersburg','20:00','1',34),(23,NULL,'2017-04-23',2,'-','-','Zubrienok','19:00','0',35),(24,NULL,'2017-04-28',2,'-','-','SPb','07:00','1',35),(25,NULL,'2017-04-23',2,'-','Spb','Zubrienok','19:00','0',36),(26,NULL,'2017-04-28',2,'-','Zubrienok','SPb','07:00','1',36),(27,NULL,'2017-04-23',2,'-','SPb','Zubrienok','19:00','0',37),(28,NULL,'2017-04-28',2,'-','Zubrienok','SPb','07:00','1',37),(29,NULL,'2017-04-23',2,'-','Saint Petersburg','Zubrionok','19:00','0',38),(30,NULL,'2017-04-28',2,'-','Zubrionok','Saint Petersburg','07:00','1',38),(31,NULL,'2017-04-23',2,'-','Saint Petersburg','Zubrionok','19:00','0',39),(32,NULL,'2017-04-28',2,'-','Zubrionok','Saint Petersburg','07:00','1',39),(33,NULL,'2017-04-23',0,'B2 892','Berlin-Schoenefeld','Minsk','16:45','0',40),(34,NULL,'2017-04-28',0,'B2 891','Minsk','Berlin-Schoenefeld','12:10','1',40),(35,NULL,'2017-04-22',3,'-','Berlin','NDC \"Zubronok\"','15:00','0',41),(36,NULL,'2017-04-28',3,'-','NDC \"Zubronok\"','Berlin','10:00','1',41),(37,NULL,'2017-04-24',0,'Belavia 858','Helsinki (HEL)','Minsk, Belarus','18:00','0',42),(38,NULL,'2017-04-29',0,'Ukraine Intl Air 894','Minsk, Belarus (MSQ)','Kiev, Ukraine (KBP)','07:00','1',42),(39,NULL,'2017-04-23',0,'TK283','Minsk','Minsk','13:00','0',43),(40,NULL,'2017-04-29',0,'TK284','Minsk','Minsk','16:20','1',43),(41,NULL,'2017-04-23',0,'TK283','Minsk','Minsk','13:00','0',44),(42,NULL,'2017-04-29',0,'TK284','Minsk','Minsk','16:20','1',44),(43,NULL,'2017-04-18',0,'test','test','test','12:12','0',46),(44,NULL,'2017-04-18',0,'test','test','test','12:12','1',46),(45,NULL,'2017-04-18',3,'HVL BG581','Potsdam','Camp','12:00','0',47),(46,NULL,'2017-04-30',3,'HVL BG581','Camp','Potsdam','12:00','1',47),(47,NULL,'2017-04-23',2,NULL,NULL,NULL,NULL,'0',48),(48,NULL,'2017-04-28',2,NULL,NULL,NULL,NULL,'1',48),(49,NULL,'2017-04-22',3,NULL,'Minsk','Zubrionok',NULL,'0',49),(50,NULL,'2017-04-28',3,NULL,'Zubrionok','Minsk',NULL,'1',49),(51,NULL,'2017-04-18',0,NULL,NULL,NULL,NULL,'0',50),(52,NULL,'2017-04-18',0,NULL,NULL,NULL,NULL,'1',50),(53,NULL,'2017-04-23',3,NULL,NULL,NULL,NULL,'0',51),(54,NULL,'2017-04-28',3,NULL,NULL,NULL,NULL,'1',51),(55,NULL,'2017-04-23',2,NULL,'Bucharest','Zubronyk','18:00','0',52),(56,NULL,'2017-04-28',2,NULL,'Zubronyk','Bucharest','12:00','1',52),(57,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',53),(58,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',53),(59,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',54),(60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',54),(61,1,'2017-04-22',0,'Belavia 868','Amsterdam','Minsk','15:30','0',NULL),(62,1,'2017-04-28',0,'Belavia 865','Minsk','Paris','11:35','1',NULL),(63,2,'2017-04-23',1,'003БА, car №10','Chelyabinsk','Minsk','06:23','0',NULL),(64,2,'2017-04-28',1,'028','Minsk','Chelyabinsk','22:03','1',NULL),(65,3,'2017-04-22',0,'Belavia 868','Amsterdam','Minsk','15:30','0',NULL),(66,3,'2017-04-28',0,'Belavia 865','Minsk','Paris','11:35','1',NULL),(67,4,'2017-04-18',0,'not yet','23.04.2017','Minsk','not yet','0',NULL),(68,4,'2017-04-18',0,'not yet','28.04.2017','Minsk','not yet','1',NULL),(69,5,'2017-04-23',NULL,NULL,NULL,NULL,NULL,'0',NULL),(70,5,'2017-04-28',NULL,NULL,NULL,NULL,NULL,'1',NULL),(71,6,'2017-04-23',NULL,NULL,NULL,NULL,NULL,'0',NULL),(72,6,'2017-04-28',NULL,NULL,NULL,NULL,NULL,'1',NULL),(73,7,'2017-04-18',0,'Belavia B2 872','Geneva','Minsk','14:45','0',NULL),(74,7,'2017-04-18',0,'Belavia','Minsk','Paris','11:35','1',NULL),(75,8,'2017-04-23',1,'003БА, car №10','Chelyabinsk','Minsk','06:23','0',NULL),(76,8,'2017-04-28',1,'028','Minsk','Chelyabinsk','22:03','1',NULL),(77,9,'2017-04-23',3,'-','-','-','12:00','0',NULL),(78,9,'2017-04-28',3,'-','-','-','12:00','1',NULL),(79,10,'2017-04-23',0,'B2 872','Geneva','Minsk','1445','0',NULL),(80,10,NULL,0,NULL,NULL,NULL,NULL,'1',NULL),(81,11,'2017-04-23',1,'095Б','Moscow','Minsk','06:10','0',NULL),(82,11,'2017-04-28',1,'028','Minsk','Moscow','22:23','1',NULL),(83,12,'2017-04-23',NULL,NULL,NULL,NULL,NULL,'0',NULL),(84,12,'2017-04-28',NULL,NULL,NULL,NULL,NULL,'1',NULL),(85,13,'2017-04-23',NULL,NULL,NULL,NULL,NULL,'0',NULL),(86,13,'2017-04-28',NULL,NULL,NULL,NULL,NULL,'1',NULL),(87,14,'2017-04-23',1,'Train Number 095','Minsk','railway station','06:10','0',NULL),(88,14,'2017-04-28',1,'Train Number 318','leaving camp in the morning (time to be announced later)','leaving camp in the morning (time to be announced later)','21:50','1',NULL),(89,15,'2017-04-23',0,'B2 872','Geneva','Minsk','1445','0',NULL),(90,15,NULL,0,NULL,NULL,NULL,NULL,'1',NULL);
/*!40000 ALTER TABLE `travel_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-29 18:57:46
